import React, { useState } from 'react';
import axios from 'axios';
import FileUpload from './components/FileUpload';
import LiveFeed from './components/LiveFeed';
import XAIModal from './components/XAIModal';
import { Cpu, Zap, Database, Activity } from 'lucide-react';

const App = () => {
  const [transactions, setTransactions] = useState([]); // قائمة الـ Live Feed
  const [selected, setSelected] = useState(null);      // المعاملة المختارة للتحليل
  const [processing, setProcessing] = useState(false);  // حالة التحليل الجاري

  // المنطق المطور لمعالجة الملفات الضخمة وعرضها حياً
  const startAnalysis = async (rows) => {
    if (!rows || rows.length === 0) {
      alert("الملف لا يحتوي على بيانات صالحة!");
      return;
    }

    setProcessing(true);
    setTransactions([]); // تصفير القائمة لبدء بث جديد

    // نأخذ عينة (أول 20 سطر) لضمان سرعة العرض أمام الدكتور وعدم تعليق المتصفح
    const sample = rows.slice(0, 20);
    console.log("بدء تحليل عينة من الملف، العدد:", sample.length);

    for (const row of sample) {
      try {
        // إرسال السطر للباك إند
        const res = await axios.post('http://127.0.0.1:8000/predict', row);

        if (res.data) {
          const entry = {
            id: row.TransactionID || Math.floor(Math.random() * 1000000),
            amount: row.TransactionAmt || 0,
            prediction: res.data.prediction,
            confidence: res.data.confidence,
            explanation: res.data.explanation || [0, 0, 0, 0],
            timestamp: new Date().toLocaleTimeString(),
            raw: row
          };

          // تحديث القائمة (إضافة الجديد في الأعلى)
          setTransactions(prev => [entry, ...prev]);
        }

        // سطر حاسم: انتظار بسيط (800ms) ليظهر التأثير المباشر (Live) أمام الدكتور
        await new Promise(resolve => setTimeout(resolve, 800));

      } catch (err) {
        console.error("خطأ في الاتصال بالباك إند لهذه المعاملة:", err);
      }
    }

    setProcessing(false);
    console.log("اكتمل تحليل العينة بنجاح.");
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white p-6 md:p-12 flex flex-col gap-10" dir="rtl">

      {/* Header القسم العلوي */}
      <div className="flex flex-col md:flex-row justify-between items-center bg-[#0a0a0a] border border-gray-900 p-8 rounded-[40px] shadow-2xl relative overflow-hidden">
        {/* خلفية نيون خفيفة للهيدر */}
        <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-50"></div>

        <div className="flex items-center gap-6">
          <div className="p-4 bg-cyan-500 text-black rounded-3xl shadow-[0_0_30px_rgba(6,182,212,0.4)]">
            <Cpu size={40} />
          </div>
          <div>
            <h1 className="text-4xl font-black tracking-tighter uppercase italic">Najran Universty <span className="text-cyan-400">Shield</span></h1>
            <p className="text-[10px] text-gray-500 tracking-[0.4em] uppercase font-bold flex items-center gap-2 mt-1">
              <Zap size={12} className="text-cyan-500" /> رصد الاحتيال بالذكاء الاصطناعي
            </p>
          </div>
        </div>

        {/* زر الرفع الذكي */}
        <div className="mt-6 md:mt-0">
          <FileUpload onDataParsed={startAnalysis} disabled={processing} />
        </div>
      </div>

      {/* Main Content شبكة المحتوى الرئيسية */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 flex-1 min-h-0">

        {/* الجهة اليمنى: Live Feed */}
        <div className="lg:col-span-7 bg-[#0a0a0a] border border-gray-900 rounded-[40px] p-8 flex flex-col h-[700px] shadow-2xl overflow-hidden relative">
          <div className="flex justify-between items-center mb-8 px-2">
            <h2 className="text-xl font-bold flex items-center gap-3">
              <Database className="text-cyan-500" /> التدفق المباشر للبيانات
            </h2>
            {processing && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-cyan-400 animate-pulse font-mono tracking-widest">ANALYZING_LIVE...</span>
                <Activity size={16} className="text-cyan-400 animate-spin" />
              </div>
            )}
          </div>

          <div className="flex-1 overflow-hidden relative">
            <LiveFeed transactions={transactions} onSelect={setSelected} />
          </div>
        </div>

        {/* الجهة اليسرى: XAI Modal/Panel */}
        <div className="lg:col-span-5 h-[700px]">
          <XAIModal selected={selected} />
        </div>
      </div>

      {/* Footer التذييل */}
      <footer className="flex justify-between items-center text-gray-800 text-[10px] font-bold tracking-[0.3em] uppercase mt-4 px-4">
        <span>NAJRAN UNIVERSTY SECURITY SYSTEMS</span>
        <div className="flex items-center gap-4 opacity-50">
          <span>Project Graduation: CS UNIT</span>
        </div>
      </footer>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #1a1a1a; border-radius: 20px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #06b6d4; }
      `}</style>
    </div>
  );
};

export default App;