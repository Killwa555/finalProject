import React from 'react';
import Papa from 'papaparse';
import { Upload, FileWarning } from 'lucide-react';

const FileUpload = ({ onDataParsed, disabled }) => {
    const handleFile = (e) => {
        const file = e.target.files[0];
        if (!file) return;

        // إعدادات PapaParse المتقدمة لاكتشاف الفواصل تلقائياً
        Papa.parse(file, {
            header: true,
            skipEmptyLines: 'greedy',
            dynamicTyping: true,
            // سطر حاسم: يطلب من المكتبة تجربة كل أنواع الفواصل الممكنة
            delimitersToGuess: [',', ';', '\t', '|', ' '],
            complete: (results) => {
                // فحص هل نجح التقسيم لأكثر من عمود؟
                const firstRow = results.data[0];
                const columnCount = firstRow ? Object.keys(firstRow).length : 0;

                if (columnCount <= 1) {
                    alert("خطأ في تنسيق الملف: يبدو أن البيانات كلها في عمود واحد. تأكد أن الملف ملف CSV صالح.");
                    console.error("Columns detected:", columnCount);
                    return;
                }

                // تنظيف البيانات من الأسطر التي لا تحتوي على ID
                const cleanData = results.data.filter(row => row.TransactionID);

                console.log(`تم اكتشاف ${columnCount} أعمدة و ${cleanData.length} أسطر.`);
                onDataParsed(cleanData);
            },
            error: (err) => alert("حدث خطأ أثناء قراءة الملف: " + err.message)
        });
    };

    return (
        <div className="flex flex-col items-center">
            <label className={`flex items-center gap-3 px-8 py-4 rounded-2xl font-bold cursor-pointer transition-all ${disabled ? 'bg-gray-800 text-gray-500 cursor-not-allowed' : 'bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_20px_rgba(6,182,212,0.4)]'}`}>
                <Upload size={24} />
                <span>{disabled ? "جاري المعالجة..." : "رفع ملف العمليات"}</span>
                <input type="file" accept=".csv" className="hidden" onChange={handleFile} disabled={disabled} />
            </label>
            {disabled && <p className="text-[10px] text-cyan-500 mt-2 animate-pulse uppercase tracking-widest">Processing Large Dataset...</p>}
        </div>
    );
};

export default FileUpload;