import React from 'react';
import { motion } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip } from 'recharts';
import { Info, Target, AlertCircle } from 'lucide-react';

const XAIModal = ({ selected }) => {
    if (!selected) return (
        <div className="h-full flex flex-col items-center justify-center text-gray-700 border border-gray-900 rounded-3xl bg-black/20">
            <Target size={60} className="mb-4 opacity-10" />
            <p className="text-sm px-10 text-center opacity-40 italic">اختر أي معاملة من القائمة اليسرى لعرض تحليل الذكاء الاصطناعي المفصل (SHAP)</p>
        </div>
    );

    const data = [
        { name: 'المبلغ', val: selected.explanation[0] || 0.1 },
        { name: 'المنتج', val: selected.explanation[1] || -0.2 },
        { name: 'البطاقة', val: selected.explanation[2] || 0.5 },
        { name: 'العنوان', val: selected.explanation[3] || -0.1 },
    ];

    return (
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="h-full flex flex-col bg-[#0d0d0d] border border-gray-800 rounded-3xl p-8 relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 p-10 opacity-5"><Info size={200} /></div>

            <div className="flex items-center gap-3 mb-8 border-b border-gray-800 pb-4">
                <div className={`p-2 rounded-lg ${selected.prediction === 1 ? 'bg-pink-500 text-black' : 'bg-cyan-500 text-black'}`}>
                    <AlertCircle size={20} />
                </div>
                <h3 className="text-xl font-black uppercase tracking-tighter">AI Decision Reasoning</h3>
            </div>

            <div className="flex-1 w-full min-h-[300px] mb-6">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={data} layout="vertical" margin={{ left: 20 }}>
                        <XAxis type="number" hide />
                        <YAxis dataKey="name" type="category" stroke="#888" fontSize={12} width={70} />
                        <Tooltip cursor={{ fill: 'rgba(255,255,255,0.05)' }} contentStyle={{ backgroundColor: '#000', border: '1px solid #333', borderRadius: '10px' }} />
                        <Bar dataKey="val" radius={[0, 5, 5, 0]}>
                            {data.map((entry, index) => (
                                <Cell key={index} fill={entry.val > 0 ? '#db2777' : '#06b6d4'} />
                            ))}
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </div>

            <div className={`p-5 rounded-2xl border ${selected.prediction === 1 ? 'border-pink-900 bg-pink-950/20' : 'border-cyan-900 bg-cyan-950/20'}`}>
                <p className="text-sm font-bold mb-2 flex items-center gap-2">
                    {selected.prediction === 1 ? <span className="text-pink-500">تحليل عالي الخطورة</span> : <span className="text-cyan-400">تحليل منخفض الخطورة</span>}
                </p>
                <p className="text-xs text-gray-400 leading-relaxed text-right">
                    {selected.prediction === 1
                        ? "تشير قيم SHAP الموجبة (باللون الوردي) إلى أن مبلغ العملية ونوع البطاقة كانا العاملين الأكثر حسماً في تصنيفها كاحتيال."
                        : "العملية تبدو طبيعية جداً، والعوامل الموضحة بالأزرق هي التي أكدت للنظام سلامة هذه المعاملة ماليًا."}
                </p>
            </div>
        </motion.div>
    );
};

export default XAIModal;