import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldAlert, ShieldCheck, Activity } from 'lucide-react';

const LiveFeed = ({ transactions, onSelect }) => {
    return (
        <div className="flex-1 overflow-y-auto pr-3 space-y-4 custom-scrollbar h-full">
            <AnimatePresence>
                {transactions.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-gray-700 opacity-20 border-2 border-dashed border-gray-800 rounded-3xl">
                        <Activity size={100} />
                        <p className="mt-4 text-xl">ارفع ملفاً لبدء البث المباشر للعمليات</p>
                    </div>
                ) : (
                    transactions.map((tx, idx) => (
                        <motion.div
                            key={idx}
                            initial={{ opacity: 0, x: 50 }}
                            animate={{ opacity: 1, x: 0 }}
                            onClick={() => onSelect(tx)}
                            className={`p-5 rounded-2xl border-r-8 bg-[#0d0d0d] cursor-pointer hover:bg-white/[0.05] transition-all flex justify-between items-center ${tx.prediction === 1 ? 'border-pink-600 shadow-[0_0_15px_rgba(219,39,119,0.2)]' : 'border-cyan-500'}`}
                        >
                            <div className="flex items-center gap-5">
                                {tx.prediction === 1 ? <ShieldAlert className="text-pink-500" size={28} /> : <ShieldCheck className="text-cyan-400" size={28} />}
                                <div>
                                    <p className="text-[10px] text-gray-500 font-mono tracking-widest uppercase font-bold">Transaction ID: {tx.id}</p>
                                    <p className="text-xl font-black text-white">${tx.amount}</p>
                                </div>
                            </div>
                            <div className="text-left">
                                <span className={`text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest ${tx.prediction === 1 ? 'bg-pink-500/20 text-pink-500' : 'bg-cyan-500/20 text-cyan-400'}`}>
                                    {tx.prediction === 1 ? 'Fraud Detected' : 'Verified Safe'}
                                </span>
                                <p className="text-[10px] text-gray-600 mt-2 font-mono">{tx.timestamp}</p>
                            </div>
                        </motion.div>
                    ))
                )}
            </AnimatePresence>
        </div>
    );
};

export default LiveFeed;